package com.pxy.lesson7;

public class Sword implements IMount {
	public String name;
	
	public Sword(){}
	public Sword(String name){
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public void move(){
		System.out.println("这是"+this.name+"牌飞剑，时速能达到8888公里！");
	}
	@Override
	public void run() {
		System.out.println("传说中的神器，只要你坐上来，就是剑人了！！！");
	}
}
