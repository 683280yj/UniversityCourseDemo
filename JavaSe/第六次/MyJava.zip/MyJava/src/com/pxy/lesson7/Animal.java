package com.pxy.lesson7;

/**
 * 动物类
 * @author Administrator
 *
 */
public abstract class Animal {
	private String name;

	public Animal(){}
	public Animal(String name){
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//移动
	public abstract void move();
}
