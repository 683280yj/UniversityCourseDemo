package com.pxy.lesson7;

public class Dog extends Animal {

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("狗一边汪汪汪的叫，一边狂奔！");
	}

}
