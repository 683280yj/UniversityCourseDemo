package com.pxy.lesson7;

/**
 * 坐骑接口
 * @author Administrator
 *
 */
public interface IMount {
	public void run();
}
