package com.pxy.lesson7;

public class Role {
	private String name;
	private IMount mount;	//应该是什么类型？
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public IMount getMount() {
		return mount;
	}
	public void setMount(IMount mount) {
		this.mount = mount;
	}
	
	
}
