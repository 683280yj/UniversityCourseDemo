package com.pxy.lesson7;

public class Cat extends Animal implements IMount {

	public Cat(){}
	public Cat(String name){
		super(name);
	}
	
	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("我叫"+this.getName()+"，我跑起来能达到100米/秒！");
	}
	@Override
	public void run() {
		System.out.println("长八米，宽八米的猫，向你跑来，就问你怕不怕！");
	}

}
