package com.pxy.lesson7;

public class Car implements IMount {
	public String name;
	
	public Car(){}
	public Car(String name){
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public void move(){
		System.out.println("这是"+this.name+"牌汽车，时速能达到120公里！");
	}
	@Override
	public void run() {
		System.out.println("开始变形！！！！");
	}
}
