create view work1_test1 as
select `HuangSir`.`test1`.`Id`      AS `Id`,
       `HuangSir`.`test1`.`Name`    AS `Name`,
       `HuangSir`.`test1`.`Date`    AS `Date`,
       `HuangSir`.`test1`.`Service` AS `Service`,
       `HuangSir`.`test1`.`Price`   AS `Price`,
       `HuangSir`.`test1`.`Tax`     AS `Tax`
from `HuangSir`.`test1`
order by `HuangSir`.`test1`.`Price`
limit 2,4;

