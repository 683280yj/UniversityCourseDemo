create
    definer = cmrhyq@`%` procedure insert_user(IN user_Name varchar(32))
begin
	insert  into  userTb (userId,userName) values(null,user_Name);
end;

