create
    definer = cmrhyq@`%` procedure pro_test1_data1(IN carId int)
begin
	select Price into carId from test1 where Id=carId;
end;

