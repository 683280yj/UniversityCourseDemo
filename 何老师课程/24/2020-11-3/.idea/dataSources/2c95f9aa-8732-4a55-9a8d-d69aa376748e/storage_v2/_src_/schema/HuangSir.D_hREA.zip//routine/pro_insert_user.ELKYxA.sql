create
    definer = cmrhyq@`%` procedure pro_insert_user(IN userName varchar(32), IN userAge int)
begin
	insert into tb_user values(null,userName,userAge);
	end;

