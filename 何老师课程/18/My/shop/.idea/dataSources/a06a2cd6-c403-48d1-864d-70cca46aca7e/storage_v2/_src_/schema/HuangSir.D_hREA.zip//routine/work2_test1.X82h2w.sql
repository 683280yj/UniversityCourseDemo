create
    definer = cmrhyq@`%` procedure work2_test1(IN carId int)
begin
	select *,if(Tax is null,Price*0.02,Price*0.02+Tax) as '增长' from test1 where Id=carId;
end;

