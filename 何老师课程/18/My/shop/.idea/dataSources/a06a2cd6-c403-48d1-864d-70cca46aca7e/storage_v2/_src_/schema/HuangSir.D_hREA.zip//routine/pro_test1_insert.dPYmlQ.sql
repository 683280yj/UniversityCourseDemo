create
    definer = cmrhyq@`%` procedure pro_test1_insert(IN carId int, IN carName varchar(50), IN carDate varchar(50),
                                                    IN carService varchar(50), IN carPrice int, IN carTax int)
begin
	insert into test1 values(carId,carName,carDate,carService,carPrice,carTax);
end;

