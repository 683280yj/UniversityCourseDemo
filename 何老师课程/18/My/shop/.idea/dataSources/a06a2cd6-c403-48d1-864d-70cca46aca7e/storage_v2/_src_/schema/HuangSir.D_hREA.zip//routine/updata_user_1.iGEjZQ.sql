create
    definer = cmrhyq@`%` procedure updata_user_1(IN user_ID int, IN userName varchar(32))
begin
##delete from userTb where userID=user_ID; 
update userTb set userId=user_ID,userName=user_Name;
end;

