create definer = cmrhyq@`%` trigger trigger_after_insert_on_test3
    before delete
    on test1
    for each row
begin
		insert into test3 values(old.Id,old.Name,old.Date,old.Service,old.Price,old.Tax);
end;

