﻿//获取url
function GetPageName(){
    var url=window.location.href;
    var tmp= new Array();
    tmp=url.split("/");
    var pp=tmp[tmp.length-1];
    tmp=pp.split("?");
    return tmp;
}

//首页顶部导航
$(function(){
	    $("#j_global_nav li").hover(function(){
		    $(this).addClass("current").children("dl").show();
	    },function(){
		    $(this).removeClass("current").children("dl").hide();
	    })

	    $("#j_global_nav li a").focus(function(){
		    $(this).blur();
	    })
})

//内页顶部导航
$(function(){
	$("#j_global_nav2 li").hover(function(){
		$(this).addClass("current").children("dl").show().end().css("background","none");
	},function(){
		$(this).removeClass("current").children("dl").hide().end().css("background","url(/images/sub_nav_vline2.png) no-repeat left center");
		var index=$("#j_global_nav2 li").index(this);
		if(index==0){
		    $(this).css("background","none");
		}
	})
})

//左边导航初始化
function inti(){
	$("#j_park_item_nav li").removeClass("current");
	$("#j_park_item_nav li>div").hide();
	$("#j_park_item_nav li a").removeClass("on");
}

//左边导航展开、收缩
$(function(){
	$("#j_park_item_nav li>a").click(function(){
		$("#j_park_item_nav li").removeClass("current").find("div").slideUp(function(){
			$("#j_park_item_nav div a").removeClass("on");
		});
		$(this).parent("li").addClass("current");
		if( $(this).parent("li").find("div").is(":hidden")){
			$(this).parent("li").find("div").slideDown();
		}
		$(this).blur();
	})		
	
	//左边二级菜单点击效果
	$("#j_park_item_nav div a").click(function(){
		$("#j_park_item_nav div a").removeClass("on");
		$(this).addClass("on");
		$(this).blur();
	})	
})

//幻灯图片
$(function(){
	    var n=1;
	    var t;
	    var lis=$("#j_focus_pic li").size();
	    var liw=$("#j_focus_pic li").width();
	    var $ul=$("#j_focus_pic ul");
	    $("#j_number").text(n+" / "+lis);
	    $ul.width(lis*liw);
    	
	    $("#j_prev").click(function(){
		    clearInterval(t);
		    $("#j_play_pause").removeClass("play");
		    goPrev();
	    })
    	
	    $("#j_next").click(function(){
		    clearInterval(t);
		    $("#j_play_pause").removeClass("play");
		    goNext();
	    })
    	
	    $("#j_play_pause").toggle(function(){
		    if(lis>0){
		        t=setInterval(goNext,3000);
		        $(this).addClass("play");
		    }
	    },function(){
		    clearInterval(t);
		    $(this).removeClass("play");
	    }).trigger("click")


        function goPrev(){
	        if(!$ul.is(":animated")){
		        if(n==1){
			        $ul.animate({"margin-left":"-="+liw*(lis-1)},500);
			        n=lis;
		        }else{
			        $ul.animate({"margin-left":"+="+liw},500);
			        n--;
		        }
	        }
	        $("#j_number").text(n+" / "+lis);
        }

        function goNext(){
	        if(!$ul.is(":animated")){
		        if(n==lis){
			        $ul.animate({"margin-left":0},500);
			        n=1;
		        }else{
			        $ul.animate({"margin-left":"-="+liw},500);
			        n++;
		        }
	        }
	        $("#j_number").text(n+" / "+lis);
        }


})

/*方特欢乐世界、方特梦幻王国tab
$(function(){
	var index=0;
	$("#j_tab_menu li").mouseover(function(){
		index=$("#j_tab_menu li").index(this);
		if(index==0){
			$("#j_tab_menu").removeClass("tab-menu-1");
		}else{
			$("#j_tab_menu").addClass("tab-menu-1");
		}
		$("#j_tab_contnet div").eq(index).fadeIn().siblings().hide();
	})
})
*/	
