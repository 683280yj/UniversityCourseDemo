﻿//三级页导航
$(function(){
	$("#j_global_nav2 li").hover(function(){
		$(this).addClass("current").children("dl").show().end().css("background","none").next().css("background","none");
	},function(){
		$(this).removeClass("current").children("dl").hide().end().css("background","url(../images/sub_nav_vline2.png) no-repeat left center")
		.next().css("background","url(../images/sub_nav_vline2.png) no-repeat left center");
	})
})


//图片浏览
// $(function(){
// 	var n=1;
// 	var t;
// 	var lis=$("#j_focus_pic li").size();
// 	var liw=$("#j_focus_pic li").width();
// 	var $ul=$("#j_focus_pic ul");
// 	$("#j_number").text(n+" / "+lis);
// 	$ul.width(lis*liw);
// 	$("#j_prev").click(function(){
// 		clearInterval(t);
// 		$("#j_play_pause").removeClass("play");
// 		goPrev();
// 	})
// 	
// 	$("#j_next").click(function(){
// 		clearInterval(t);
// 		$("#j_play_pause").removeClass("play");
// 		goNext();
// 	})
// 	
// 	function goPrev(){
// 		if(!$ul.is(":animated")){
// 			if(n==1){
// 				$ul.animate({"margin-left":"-="+liw*(lis-1)},500);
// 				n=lis;
// 			}else{
// 				$ul.animate({"margin-left":"+="+liw},500);
// 				n--;
// 			}
// 		}
// 		$("#j_number").text(n+" / "+lis);
// 	}

// 	function goNext(){
// 		if(!$ul.is(":animated")){
// 			if(n==lis){
// 				$ul.animate({"margin-left":0},500);
// 				n=1;
// 			}else{
// 				$ul.animate({"margin-left":"-="+liw},500);
// 				n++;
// 			}
// 		}
// 		$("#j_number").text(n+" / "+lis);
// 	}
// 	
// 	$("#j_play_pause").toggle(function(){
// 		if(lis>0){
// 		    t=setInterval(goNext,3000);
// 		    $(this).addClass("play");
// 		}
// 	},function(){
// 		clearInterval(t);
// 		$(this).removeClass("play");
// 	}).trigger("click")
// })


//方特欢乐世界、方特梦幻王国tab


$(function(){
	var index=0;
	$("#j_tab_menu li").mouseover(function(){
		index=$("#j_tab_menu li").index(this);
		if(index==0){
			$("#j_tab_menu").removeClass("tab-menu-1");
		}else{
			$("#j_tab_menu").addClass("tab-menu-1");
		}
		$("#j_tab_contnet div").eq(index).fadeIn().siblings().hide();
	})
})


 
function sAlert(strTitle,strContent){ 
    var msgw,msgh,bordercolor; 
    msgw=400;//提示窗口的宽度 
    msgh=120;//提示窗口的高度 
    titleheight=25; //提示窗口标题高度 
    bordercolor="#e78e03";//提示窗口的边框颜色 
    titlecolor="#ffffff";//提示窗口的标题颜色

    var sWidth,sHeight; 
    sWidth=document.body.offsetWidth; 
    sHeight=screen.height; 
    var bgObj=document.createElement("div"); 
    bgObj.setAttribute('id','bgDiv'); 
    bgObj.style.position="absolute"; 
    bgObj.style.top="0"; 
    bgObj.style.filter="progid:DXImageTransform.Microsoft.Alpha(style=3,opacity=25,finishOpacity=75"; 
    bgObj.style.opacity="0.6"; 
    bgObj.style.left="0"; 
    bgObj.style.width=900 + "px"; 
    bgObj.style.height=320 + "px"; 
    bgObj.style.zIndex = "10000"; 
    document.body.appendChild(bgObj);

    var msgObj=document.createElement("div") 
    msgObj.setAttribute("id","msgDiv"); 
    msgObj.setAttribute("align","center"); 
    msgObj.style.background="white"; 
    msgObj.style.border="1px solid " + bordercolor; 
    msgObj.style.position = "absolute"; 
    msgObj.style.left = "50%"; 
    msgObj.style.top = "50%"; 
    msgObj.style.width="300px";
    msgObj.style.font="12px/1.6em Verdana, Geneva, Arial, Helvetica, sans-serif"; 
    msgObj.style.marginLeft = "-225px" ; 
    msgObj.style.marginTop = -75+document.documentElement.scrollTop+"px"; 
    msgObj.style.width = msgw; 
    msgObj.style.height =msgh; 
    msgObj.style.textAlign = "center"; 
    msgObj.style.lineHeight ="25px"; 
    msgObj.style.zIndex = "10001";

    var title=document.createElement("h4"); 
    title.setAttribute("id","msgTitle"); 
    title.setAttribute("align","right"); 
    title.style.margin="0"; 
    title.style.padding="3px"; 
    title.style.background=bordercolor; 
    title.style.filter="progid:DXImageTransform.Microsoft.Alpha(startX=20, startY=20, finishX=100, finishY=100,style=1,opacity=75,finishOpacity=100);"; 
    title.style.opacity="0.75"; 
    title.style.border="1px solid " + bordercolor; 
    title.style.height="18px"; 
    title.style.font="12px Verdana, Geneva, Arial, Helvetica, sans-serif"; 
    title.style.color="white"; 
    title.style.cursor="pointer"; 
    title.title = "点击关闭"; 
    title.innerHTML="<table border='0′ width='100%'><tr><td align='left'><b>"+ strTitle +"</b></td><td>关闭</td></tr></table></div>"; 
    title.onclick=function(){ 
    document.body.removeChild(bgObj); 
    document.getElementById("msgDiv").removeChild(title); 
    document.body.removeChild(msgObj); 
    } 
    document.body.appendChild(msgObj); 
    document.getElementById("msgDiv").appendChild(title); 
    var txt=document.createElement("p"); 
    txt.style.margin="1em 0" 
    txt.setAttribute("id","msgTxt"); 
    txt.innerHTML=strContent; 
    document.getElementById("msgDiv").appendChild(txt); 
} 
 