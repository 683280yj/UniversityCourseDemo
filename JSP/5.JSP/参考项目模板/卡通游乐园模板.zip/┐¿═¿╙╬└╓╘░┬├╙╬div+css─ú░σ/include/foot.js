﻿document.write('\
	<footer class="foot ma">\
		<div class="sub-nav"><a target="_blank" href="http://www.fangte.com/help/aboutus.aspx" title="关于方特">关于方特</a>&nbsp;|&nbsp; <a target="_blank" href="http://www.fangte.com/help/services_article.aspx" title="服务条款">服务条款</a>&nbsp;|&nbsp; <a target="_blank" href="http://www.fangte.com/help/lay.aspx" title="相关法律">相关法律</a>&nbsp;|&nbsp; <a target="_blank" href="http://www.fangte.com/help/privacy.aspx" title="隐私权声明">隐私权声明</a>&nbsp;|&nbsp; <a target="_blank" href="http://www.fangte.com/help/brand.aspx" title="商标信息">商标信息</a>&nbsp;|&nbsp; <a target="_blank" href="http://www.fangte.com/help/copyright.aspx" title="版权声明">版权声明</a>&nbsp;|&nbsp; <a target="_blank" href="http://www.fangte.com/help/contact.aspx" title="联系我们">联系我们</a> </div>\
		<div>版权所有：华强文化科技集团《增值电信业务经营许可证》 许可证编号：粤B2-20090023</div>\
		<div>ICP备案号：粤ICP备05131581号-2　文网文 【2009】038号  <a target="_blank" href="http://www.fangte.com/xkz.html" class="tdu" title="信息网络传播视听节目许可证">信息网络传播视听节目许可证</a> AVSP1910586号</div>\
	</footer>\
')