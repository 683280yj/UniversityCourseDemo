document.write('\
	 <IFRAME NAME="neepage2" width="1000" height="348" frameBorder="0" marginwidth=0 marginheight=0 SRC="banner.html" ></IFRAME>\
')