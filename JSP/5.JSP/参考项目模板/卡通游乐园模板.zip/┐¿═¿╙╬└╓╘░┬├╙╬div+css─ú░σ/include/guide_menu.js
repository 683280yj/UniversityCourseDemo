document.write('\
              <div><img src="images/btm_nav.png" border="0" usemap="#Map">\
                    <map name="Map">\
                        <area shape="rect" coords="241,12,380,154" href="http://www.fangte.com/ticket/" target="_blank">\
                        <area shape="rect" coords="432,11,570,150" href="yqdt.html">\
                        <area shape="rect" coords="621,13,760,149" href="jtzn.html">\
                        <area shape="rect" coords="812,12,951,149" href="http://bbs.fangte.com/forum.php?mod=forumdisplay&fid=246" target="_blank">\
                        <area shape="rect" coords="52,9,189,150" href="tjxl.html">\
                    </map>\
                </div>\
')