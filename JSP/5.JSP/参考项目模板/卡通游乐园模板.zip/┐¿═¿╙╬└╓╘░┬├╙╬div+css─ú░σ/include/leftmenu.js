document.write('\
<aside class="fl" >\
                        <div class="park-item-nav" id="j_park_item_nav">\
                           <ul>\
                                <li id="j_parkshow"><a href="parkshow.html" id="intro" class="first">项目介绍</a>\
									<div>\
										<a href="/pftcb.html">方特城堡</a>\
										<a href="/pklwj.html">恐龙危机</a>\
										<a href="/phlw.html">海螺湾</a>\
										<a href="/ptckld.html">逃出恐龙岛</a>\
										<a href="/pfyjx.html">飞越极限</a>\
										<a href="/ptglxs.html">唐古拉雪山</a>\
										<a href="/pdyms.html">电影魔术大揭秘</a>\
										<a href="/pyzblh.html">宇宙博览会</a>\
										<a href="/psmzg.html">生命之光</a>\
										<a href="/pdblx.html">嘟比历险</a>\
										<a href="/pdbtkx.html">嘟比脱口秀之十二生肖快乐街</a>\
										<a href="/plz.html">聊斋</a>\
										<a href="/pbfy.html">暴风眼</a>\
										<a href="/phltd.html">欢乐天地</a>\
										<a href="/pjdkc.html">极地快车</a>\
									</div>\
								</li>\
								<li id="j_ychd"><a href="/ychd.html">演出活动</a></li>\
								<li id="j_mwcy"><a href="/mwcy.html">美味餐饮</a></li>\
								<li id="j_hlgw"><a href="/hlgw.html">欢乐购物</a></li>\
								<li id="j_news"><a href="/news.shtml">新闻公告</a>\
                                    <div>\
                                        <a href="/news/list/88/news_88_1.shtml?type=88">媒体报道</a>\
                                        <a href="/news/list/87/news_87_1.shtml?type=87">新闻动态</a>\
                                        <a href="/news/list/86/news_86_1.shtml?type=86">园区公告</a>\
                                    </div>\
                                </li>\
								<li id="j_yysj"><a href="/yysj.html">营业时间</a></li>\
								<li id="j_mpjg"><a href="/mpjg.html">门票价格</a></li>\
								<li><a href="/tjxl.html">推荐线路</a></li>\
								<li><a href="/yqdt.html">园区地图</a></li>\
								<li><a href="/jtzn.html">交通指南</a></li>\
								<li><a href="http://bbs.fangte.com/forum.php?mod=forumdisplay&fid=246" target="_blank" class="last">在线咨询</a></li>\
								<li><a href="/contactus.html">联系我们</a></li>\
                            </ul>\
                        </div>\
                        <IFRAME NAME="neepage" width="252" height="500" frameBorder="0" marginwidth=0 marginheight=0 SRC="yjgl.html" ></IFRAME>\
                    </aside>\
')