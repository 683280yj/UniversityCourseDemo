document.write('\
                <nav class="nav-blue" id="j_global_nav2">\
                        <h1 class="mt10 ml20 mr25 fl" style="margin-right:116px;"><a href="http://www.xiaopangniu.net/" title="方特欢乐世界.郑州"><img src="images/zhengzhou_logo.jpg" class="mt2" id="j_logo"></a></h1>\
                        <ul>\
                        <li>\
                        <a class="jdhs" title="方特酒店" target="_blank" href="http://hotel.fangte.com">方特酒店</a>\
                        </li>\
                        <li>\
                        <a class="zxyd" title="在线预订" target="_blank" href="http://www.fangte.com/ticket/">在线预订</a>\
                            <dl>\
                            <dd class="nobd"><a title="门票" target="_blank"  href="http://www.fangte.com/ticket/">门&nbsp;&nbsp;票</a></dd>\
                            <dd><a title="酒店" target="_blank" href="http://hotel.fangte.com">酒&nbsp;&nbsp;店</a></dd>\
                            <dd><a title="宴席" target="_blank" href="http://hotel.fangte.com">宴&nbsp;&nbsp;席</a></dd>\
                            <dd><a title="高尔夫" target="_blank" href="http://hotel.fangte.com">高尔夫</a></dd>\
                            </dl>\
                        </li>\
                        <li>\
                        <a class="jchd" title="精彩活动" target="_blank" href="http://www.fangte.com/active/2012/Activity.html">精彩活动</a>\
                        </li>\
                        <li>\
                        <a class="wsgw" title="网上购物" target="_blank" href="http://shopping.fangte.com/">网上购物</a>\
                      		<dl style="display: none;">\
                            <dd class="nobd">\
                            <a title="方特网上商城" target="_blank" href="http://shopping.fangte.com/">方特网上商城&nbsp;&nbsp;</a>\
                            </dd>\
                            <dd>\
                            <a title="嘟噜嘟比礼品店" target="_blank" href="http://duludubi.taobao.com/">嘟噜嘟比礼品店</a>\
                            </dd>\
                            </dl>\
                        </li>\
                        <li>\
                        <a class="lysq" title="旅游社区" target="_blank" href="http://bbs.fangte.com/forum.php?mod=forumdisplay&fid=246">旅游社区</a\
                        </li>\
                        </ul>\
                        <span class="L"></span>\
                        <span class="r"></span>\
                </nav>\
              <div class="area">\
               	  <ul>\
                    	<li><a target="_blank" href="http://www.fangte.com/">方特网</a></li>\
						<li><a target="_blank" href="http://www.xiaopangniu.net/">郑州</a></li>\
                    	<li><a target="_blank" href="http://qingdao.fangte.com/">青岛</a></li>\
                        <li><a target="_blank" href="http://wuhu.fangte.com/">芜湖</a></li>\
                        <li><a target="_blank" href="http://taian.fangte.com/">泰安</a></li>\
                        <li><a target="_blank" href="http://zhuzhou.fangte.com">株洲</a></li>\
                        <li><a target="_blank" href="http://shenyang.fangte.com/">沈阳</a></li>\
                        <li><a target="_blank" href="http://shantou.fangte.com/">汕头</a></li>\
                        <li><a target="_blank" href="http://chongqing.fangte.com/">重庆</a></li>\
                </ul>\
                </div>\
')