//<![CDATA[
jq(function(){
	(function(){
		var curr = 0;
		jq("#jsNav .trigger").each(function(i){
			jq(this).click(function(){
				curr = i;
				jq("#js a").eq(i).fadeIn("slow").siblings("a").hide();
				jq(this).siblings(".trigger").removeClass("imgSelected").end().addClass("imgSelected");
				return false;
			});
		});
		
		var pg = function(flag){
			//flag:true��ʾǰ���� false��ʾ��
			if (flag) {
				if (curr == 0) {
					todo = 2;
				} else {
					todo = (curr - 1) % 3;
				}
			} else {
				todo = (curr + 1) % 3;
			}
			jq("#jsNav .trigger").eq(todo).click();
		};
		
		//ǰ��
		jq("#prev").click(function(){
			pg(true);
			return false;
		});
		
		//��
		jq("#next").click(function(){
			pg(false);
			return false;
		});
		
		//�Զ���
		var timer = setInterval(function(){
			todo = (curr + 1) % 3;
			jq("#jsNav .trigger").eq(todo).click();
		},6000);
		
		//�����ͣ�ڴ�������ʱֹͣ�Զ���
		jq("#jsNav a").hover(function(){
				clearInterval(timer);
			},
			function(){
				timer = setInterval(function(){
					todo = (curr + 1) % 3;
					jq("#jsNav .trigger").eq(todo).click();
				},4500);			
			}
		);
	})();
});
//]]>
