// JavaScript Document$(function(){
$(document).ready(function() {
/*
//$(".src .src1").scrollable({size:1,items:".src .src1 ul",loop:true,prev:".pre",next:".next"}).autoscroll({ autoplay: true,interval:4000 });
$(".demo .src4").scrollable({size:1,items:".demo .src4 ul",loop:true}).autoscroll({ autoplay: true,interval:4000 });
$(".name .name1").scrollable({size:1,items:".name .name1 ul",loop:true,prev:".ak",next:".mk"}).autoscroll({ autoplay: true,interval:4000 });
$(".src8 .src9").scrollable({size:1,items:".src8 .src9 ul",loop:true,prev:".ps",next:".pl"}).autoscroll({ autoplay: true,interval:4000 });

$("#chained2").scrollable({size:3,items:"#chained2 ul",loop:true}).autoscroll({ autoplay: true,interval:4000 }).navigator({navi:".nv2",naviItem:"dd",activeClass:"current"});
$("#chained3").scrollable({size:5,items:"#chained3 ul",loop:true}).autoscroll({ autoplay: true,interval:4000 }).navigator({navi:".nv3",naviItem:"dd",activeClass:"current"});

$(".hot_service ul").tabs(".hot_big > div", {effect: 'fade',loop:true,fadeOutSpeed: "fast",rotate: true});
$(".map ul").tabs(".src3 > div", {loop:true,rotate: true}).slideshow({autoplay:true,interval: 3000});
$(".wish ul").tabs(".src7 > div", {effect: 'fade',loop:true,fadeOutSpeed: "fast",rotate: true});

$(".fick1 ul").tabs(".us > div", {effect: 'fade',loop:true,fadeOutSpeed: "fast",rotate: true}).slideshow({autoplay:true,interval: 3000});
$(".fick1 .us").tabs(".fick2 > span", {effect: 'fade',loop:true,fadeOutSpeed: "fast",rotate: true,event:"mouseover"}).slideshow({autoplay:true,interval: 3000});


$(".nav a").not(".nav a.hover").hover(function(){$(this).find("div").stop().animate({top:"2px"},300)},function(){$(this).find("div").stop().animate({top:"-36px"},400)});
//$("#chained").scrollable({size:5,items:"#chained ul",loop:true}).autoscroll({ autoplay: true,interval:4000 }).navigator({navi:".nv",naviItem:"dd",activeClass:"current"});
$(".ln_src02 ul").tabs(".ln_src01 > div", {effect: 'fade',loop:true,fadeOutSpeed: "fast",loop:true,rotate: true}).slideshow({autoplay:true,interval: 3000});
$(".ln_src2 ul").tabs(".ln_src > div", {effect: 'fade',loop:true,fadeOutSpeed: "fast",loop:true,rotate: true}).slideshow({autoplay:true,interval: 3000});
$(".ln_src04 ul").tabs(".ln_src03 > div", {effect: 'fade',loop:true,fadeOutSpeed: "fast",loop:true,rotate: true}).slideshow({autoplay:true,interval: 3000});
$(".ln_src06 ul").tabs(".ln_src05 > div", {effect: 'fade',loop:true,fadeOutSpeed: "fast",loop:true,rotate: true}).slideshow({autoplay:true,interval: 3000});

*/

$("a.np,a.kp,a.np,a.kp,a.ps,a.pl,a.sk1,a.sk2,a.ak,a.mk,a.ln_arrow01,a.ln_arrow02").click(function(){return false});

$(".fick1 ul").tabs(".us > div", {effect: 'fade',loop:true,fadeOutSpeed: "fast",rotate: true}).slideshow({autoplay:true,interval: 3000});



	$("#nav li").hover(function(){
		$(this).find(".sp").addClass("wp");
	},function(){
		$("#nav li .sp").removeClass("wp")
	});
	$(".scrollgif a").click(function(){
		_gaq.push(['_trackEvent', 'action', 'position', 'goTop']);
	});
	
	
	$("ul.nav li").hover(function(){
		$(this).find(".subNav").css("display","block");
	},function(){
		$(this).find(".subNav").css("display","none");
	});
	
	$(".subNav a").click(function(){
		var navFlag = $(this).html();
		_gaq.push(['_trackEvent', 'action', 'subNav', navFlag]);
	});

});


function do_goTop(acceleration, time) {
	window.scrollTo(0);
	/*
        acceleration = acceleration || 0.1;
        time = time || 1;

        var x1 = 0;
        var y1 = 0;
        var x2 = 0;
        var y2 = 0;
        var x3 = 0;
        var y3 = 0;

        if (document.documentElement) {
                x1 = document.documentElement.scrollLeft || 0;
                y1 = document.documentElement.scrollTop || 0;
        }
        if (document.body) {
                x2 = document.body.scrollLeft || 0;
                y2 = document.body.scrollTop || 0;
        }
        var x3 = window.scrollX || 0;
        var y3 = window.scrollY || 0;

        // ��������ҳ�涥����ˮƽ����
        var x = Math.max(x1, Math.max(x2, x3));
        // ��������ҳ�涥���Ĵ�ֱ����
        var y = Math.max(y1, Math.max(y2, y3));

        // �������� = Ŀǰ���� / �ٶ�, ��Ϊ����ԭ��ԽС, �ٶ��Ǵ��� 1 ����, ���Թ��������Խ��ԽС
        var speed = 1 + acceleration;
        window.scrollTo(Math.floor(x / speed), Math.floor(y / speed));

        // ������벻Ϊ��, �������õ���������
        if(x > 0 || y > 0) {
                var invokeFunction = "do_goTop(" + acceleration + ", " + time + ")";
                window.setTimeout(invokeFunction, time);
        }
	*/
}




/*
// ����������������뿪ʼ
var t="";
//$(window).scroll(function(){ t = setTimeout(function(){goTop();},200); });
$(window).scroll(function(){$(".scrollgif").stop().animate({opacity: '0'},0); $(".scrollgif").css({"display":"none"}); t = setTimeout(function(){goTop();},300); });

function goTop(){
	clearTimeout(t);
	 $(".scrollgif").css({"display":"block"});
	var elePos = 280;
	var footer_height = 160;

	
	if($(window).height()+$(window).scrollTop()+footer_height > $(document).height()){
		var endPos = $(document).height() - elePos - footer_height;
	} else {
		var endPos = $(window).height()+$(window).scrollTop()- elePos;
	}
	
	
	$(".scrollgif").css({"top":endPos});
	//$(".scrollgif").css({"display":"none"});
	
	
	//alert($(".scrollgif").css("opacity"));
	if($(".scrollgif").css("opacity") == 1){
		//
	}
	$(".scrollgif").animate({opacity: '1'},800);
}
*/
$(document).ready(function() {
/*
	$(".loadImg img").lazyload({
		threshold:400,
		effect : "slideDown",
		load: function(){
			$(this).parent().removeClass("loadImg");
		}
	});
*/
	if($.browser.version == "6.0"){
	} else {
		$(".scrollgif").css({"left":($(window).width()/2+964/2)+"px"});
	}
	
	
	$(window).scroll(function(){
		
		if($.browser.version == "6.0"){
			var elePos = 280;
			var footer_height = 160;

			
			if($(window).height()+$(window).scrollTop()+footer_height > $(document).height()){
				var endPos = $(document).height() - elePos - footer_height;
			} else {
				var endPos = $(window).height()+$(window).scrollTop()- elePos;
			}
			$(".scrollgif").css({"top":endPos});
		}
		
		if($(window).scrollTop() >0){
			$(".scrollgif").css("display","block");
		} else {
			$(".scrollgif").css("display","none");
		}
	});	
	
});


function getFire(){ // analytics
/*
	var defalut_num = 50;//���ðٷֱ�
	
	var m_num = Math.random();
	m_num = parseInt(m_num*100);
	
	if(m_num < defalut_num) {
		var script = document.createElement("script");
		script.type="text/javascript";
		script.src="http://s3.cnzz.com/stat.php?id=973367&web_id=973367&show=pic1";
		document.getElementsByTagName("body")[0].appendChild(script);
		
		var baiduCountUrl = window.location.pathname;
		_hmt.push(['_trackPageview',baiduCountUrl]); 
		_gaq.push(['_trackPageview']);
		
	} else {
	}
*/
}



(function($){
	$.fn.mSlider = function(options){
		var opt = $.extend({},$.fn.mSlider.defaults,options);
		var $this = $(this);
		
		var eleRoot = $("#"+opt.mSlideId);		//Ԫ�������
		var eleRoot_offsetLeft = eleRoot.offset().left;
		var eleCle = $("#"+opt.mSlideId+" > ul:first");	//��Ԫ��(ul)
		var eleData = $("#"+opt.mSlideId+" > ul > li");	//Ԫ������(li)
		
		for (var i=0;i< eleData.length; i++) {
			eleData.eq(i).attr("rel",i);
		}
		
		
		var eleCount = eleData.length;//Ԫ�ظ���
		var eleWidth = eleData.first().width();//Ԫ�ؿ���
		var wrapWidth = eleCount*eleWidth*2;//ȡ�����ul�����տ���~
		$this.freamWidth = eleRoot.width();//�������� ����
		
		eleCle.css("width",wrapWidth);//�����ul���ȸ�ֵ
		
		
		$("#"+opt.mSlideId+">ul>li").clone().prependTo($("#"+opt.mSlideId+">ul"));//����Ԫ�أ��γ�����Ԫ������
		
		
		eleRoot.mousemove(function(e){
			var xx =  e.pageX - eleRoot_offsetLeft; 
			$this.direct = xx>$this.freamWidth/2?1:0;//ȡ�÷���
			
			var t_s = parseInt($this.freamWidth/2 - xx)
			$this.para = t_s>0?t_s:-t_s;//ȡ��ƫ����
			$this.grad = $this.para/($this.freamWidth/2);
			
		});
		$(window).resize(function(){
			$this.freamWidth = eleRoot.width();//�������� ����
		});
		
		eleRoot.hover(function(){
			clearInterval($this.cInt);
			$this.cInt = setInterval(function(){
				getMove();
			},opt.intTime);
			
			if(opt.addOn){
				$("#"+opt.mSlideId+" > ul > li").addClass(opt.addOn.alpClass).hover(function(){
					$(this).removeClass(opt.addOn.alpClass);
					/*
					var relIndex = $(this).attr("rel");//�л��󽹵�ͼ
					$("#"+opt.addOn.addId).albumMove("show",relIndex);
					*/
				},function(){
					$(this).addClass(opt.addOn.alpClass);
				});
			}
			
			
		},function(){
			if(opt.addOn){
				$("#"+opt.mSlideId+" > ul > li").removeClass(opt.addOn.alpClass);
			}
			clearInterval($this.cInt);
		});
		
		function getMove(){
			
			var temp_ele_left = parseInt(eleCle.css("left"));
			if($this.direct == 1){
				if( -temp_ele_left > wrapWidth/2){//�ж��Ƿ����
					eleCle.css("left",temp_ele_left+wrapWidth/2);
					temp_ele_left = temp_ele_left+wrapWidth/2;
				}
				eleCle.css("left",temp_ele_left-parseInt(opt.stepDis*$this.grad));
			} else {
				if( temp_ele_left > 0){//�ж��Ƿ����
					eleCle.css("left",temp_ele_left-wrapWidth/2);
					temp_ele_left = temp_ele_left-wrapWidth/2;
				}
				eleCle.css("left",parseInt(eleCle.css("left"))+parseInt(opt.stepDis*$this.grad));
			}
			
		}
		
		
	};
	
	$.fn.mSlider.defaults = {
		mSlideId:"Mslide",
		stepDis:20,
		intTime:15
	};
})(jQuery);