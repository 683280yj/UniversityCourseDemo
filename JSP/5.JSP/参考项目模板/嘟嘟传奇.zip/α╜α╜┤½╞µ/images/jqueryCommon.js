// JavaScript Document
jQuery.fn.xzwTabs = function(tabList,tabTxt,options){
	var _tabList = jQuery(this).find(tabList);
	var _tabTxt = jQuery(this).find(tabTxt);
	
	//Ϊ�˼򻯲�����ǿ�ƹ涨ѡ�������li��ǩʵ��
	var tabListLi = _tabList.find("li");
	var defaults = {currentTab:0,defaultClass:"Current"};
	var o = jQuery.extend({},defaults,options);
	_tabList.find("li:eq("+o.currentTab+")").addClass(o.defaultClass);
	
	//ǿ�ƹ涨���ݲ������div��ʵ��
	_tabTxt.children("div").each(function(i){
		jQuery(this).attr("id","div"+i);						  
	}).eq(o.currentTab).css({"display":"block"});
	
	tabListLi.each(
		function(i){
			jQuery(tabListLi[i]).click(
				function(){
					if(jQuery(this).className != o.defaultClass)
					{
						jQuery(this).addClass(o.defaultClass).siblings().removeClass(o.defaultClass);
					}
					_tabTxt.children("div").eq(i).css({"display":"block"}).siblings().css({"display":"none"});
				}
			)
		}
	);
	return this;
};


;(function($){
	$.fn.extend({
		"anchorGoWhere":function(options){
			settings = $.extend({target:0, timer:1000},options);
			var _anchor = $(this);
			_anchor.each(function(i){
				$(this).click(function(){
									   //alert($(this).html());
					var _rel = $(this).attr("href").substr(1);
					switch(settings.target){
						case 1: 
							var _targetTop = $("#"+_rel).offset().top;
							$("html,body").animate({scrollTop:_targetTop},settings.timer);
							break;
						case 2:
							var _targetLeft = $("#"+_rel).offset().left;
							$("html,body").animate({scrollLeft:_targetLeft},settings.timer);
							break;
					}
					//alert(this.innerHTML);
					return false;
				});					  
			});
		}			
	});
})(jQuery);

;(function($){
	$.fn.extend({
		"setMenuOptions":function(options){
			settings = $.extend({
				width: "0",
				left:  "0"
			},options);
			this._width = settings.width;
			this._left  = settings.left;
			$(this).css({"width":this._width+"px","left":this._left+"px"});
		}			
	});		   
})(jQuery);

;(function($){
	$.fn.extend({
		"dropDownMenu_xzw":function(){
			var _elem = $(this).children("li:has(div.Lv2Box)");
			_elem.hover(
				function(){
					$(this).find("div.Lv2Box").stop(true,true).slideDown(400);
				},
				function(){
					$(this).find("div.Lv2Box").stop(true,true).slideUp("fast");
				}
			);
			
		}			
	});		   
})(jQuery);


;(function($){
	$.fn.extend({
		"transformView":function(imgArr,numArr,msgArr,options){
			settings = $.extend({
				imgHeight: "100px",
				delay: 1000
			},options);
			var _elem = $(this);
			var _lenMax = $("li", numArr).length;
			var _index = 0;
			
			var _imgArr = $(this).find(imgArr);
			var _numElem = $(this).find(numArr);
			var _msgArr = $(this).find(msgArr);
			
			$("li", _imgArr).eq(0).css("display","block");
			_numElem.eq(0).addClass("active");
			$("li", _msgArr).eq(0).fadeIn("fast");
			
			$("li",_numElem).mouseover(function(){
				_index = $("li",_numElem).index(this);
				showImg(_index);
			});
			
			_elem.hover(function(){
					if(_timer){clearInterval(_timer);}
				},
				function(){
					_timer = setInterval(function(){
						showImg(_index);
						_index++;
						if(_index == _lenMax){_index = 0;}
					},settings.delay);
				}
			);
			
			var _timer = setInterval(function(){
				showImg(_index);
				_index++;
				if(_index == _lenMax){ _index = 0;}
				},settings.delay);
			/*
			function showImg(i){
				var _height = parseInt(settings.imgHeight);
				$(imgArr).stop(true,false).animate({top : -_height*i},1000);
				$("li", numArr).eq(i).addClass("active").siblings().removeClass("active");
			}
			*/
			function showImg(i){
				$("li",_imgArr).eq(i).fadeIn("slow").siblings().hide();
				$("li",_msgArr).eq(i).fadeIn("fast").siblings().hide();
				$("li", _numElem).eq(i).addClass("active").siblings().removeClass("active");
			}
			
		}			
	});		   
})(jQuery);

jQuery(document).ready(function(){
	jQuery("ul#menu > li:has(ul)").hover(
		function(){
			jQuery(this).find("ul").stop(true,true).slideDown(400);	
		},
		function(){
			jQuery(this).find("ul").stop(true,true).slideUp("fast");
		}
	);
	jQuery("#scrolAD").transformView("#slider","#numList","#msgList",{imgHeight:"170px", delay:"2000"});

	//jQuery("a.gotoTop").anchorGoWhere({target:1});
	
	jQuery("#newsCenter").xzwTabs(".tagMenu",".tagContent");
	jQuery("#roleInfo").xzwTabs(".tagMenu",".tagContent");
	
	jQuery(".l_menu_list li").children("a").hover(function(){
		jQuery(this).css({"background-position":"0 -30px"});
	},function(){
		jQuery(this).css({"background-position":"0 0"});
	});
	
	jQuery("#index_menu li").children("a:gt(0)").hover(function(){
		jQuery(this).css({"background-position":"0 -49px"}).animate({opacity:"0.7"},"slow").animate({opacity:"1"},"slow");
	},function(){
		jQuery(this).css({"background-position":"0 0"});
	});
	
})