// JavaScript Document
function goLeft(demo,demo1,demo2,speed,key){
	if(document.getElementById(demo) == null) return false;
	var _demo = document.getElementById(demo);
	var _demo1 = document.getElementById(demo1);
	var _demo2 = document.getElementById(demo2);
	var _speed = speed;
	
	if(_demo1.offsetWidth <= _demo.clientWidth) return false;
	_demo2.innerHTML = _demo1.innerHTML;
	function marquee(){
		if(_demo2.offsetWidth - _demo.scrollLeft <= 0){
			_demo.scrollLeft -= _demo1.offsetWidth;
		}else{
			_demo.scrollLeft++;
		}
	}
	key = setInterval(marquee,_speed);
		_demo.onmouseover = function() {clearInterval(key);}
	_demo.onmouseout = function() {key=setInterval(marquee,_speed);}

}

function simplescroll(c, config) {
	if(document.getElementById(c)==null) return false;
	this.config = config ? config : {start_delay:30, speed: 30, delay:30, scrollItemCount:1};
	this.container = document.getElementById(c);
	this.pause = false;
	var _this = this;
	
	this.init = function() {
		_this.scrollTimeId = null;
		setTimeout(_this.start,_this.config.start_delay);
	}
	
	this.start = function() {
		var d = _this.container;
		var line_height = d.getElementsByTagName('li')[0].offsetHeight;
				
		if(d.scrollHeight-d.offsetHeight>=line_height)
		_this.scrollTimeId = setInterval(_this.scroll,_this.config.speed)
	};
	
	this.scroll = function() {
		if(_this.pause)return;
		var d = _this.container;
		d.scrollTop+=2;
		var line_height = d.getElementsByTagName('li')[0].offsetHeight;
		if(d.scrollTop%(line_height*_this.config.scrollItemCount)<=1){
			d.scrollTop=0;
			for(var i=0;i<_this.config.scrollItemCount;i++){
				d.appendChild(d.getElementsByTagName('li')[0]);
			}
			clearInterval(_this.scrollTimeId);
			setTimeout(_this.start,_this.config.delay);
		}
	}
	
	this.container.onmouseover=function(){_this.pause = true;}
	this.container.onmouseout=function(){_this.pause = false;}
	init();
}
