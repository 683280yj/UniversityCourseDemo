package com.chinasoft.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chinasoft.model.dao.ProductDao;
import com.chinasoft.model.entity.Products;

public class ProductControl extends HttpServlet {

	private ProductDao pd ;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		pd= new ProductDao();
		List<Products> lists = pd.showAllPro();
		HttpSession session = request.getSession();
		session.setAttribute("plist", lists);
		request.getRequestDispatcher("index.jsp").forward(request, response);
		out.flush();
		out.close();
	}



}
