package com.chinasoft.model.vo;

import java.io.Serializable;

import com.chinasoft.model.entity.Products;

//�Զ���Ĺ��ﳵ����
public class Cart implements Serializable {

	private Products products;
	//��ʼ��������
	private Integer buycount = 1;

	public Products getProducts() {
		return products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}

	public Integer getBuycount() {
		return buycount;
	}

	public void setBuycount(Integer buycount) {
		this.buycount = buycount;
	}

	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cart(Products products, Integer buycount) {
		super();
		this.products = products;
		this.buycount = buycount;
	}

}
