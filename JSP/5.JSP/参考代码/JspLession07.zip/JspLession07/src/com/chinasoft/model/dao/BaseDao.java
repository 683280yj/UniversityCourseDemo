package com.chinasoft.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class BaseDao {

	private  static final String driver="com.mysql.jdbc.Driver";
	private static final String url = "jdbc:mysql://localhost:3306/tmall";
	private static final String uname = "root";
	private static final String upwd = "root";
	
    public Connection getCon(){
    	Connection con =null;
    	try {
			Class.forName(driver);
			con = DriverManager.getConnection(url, uname, upwd);
			return con;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	return null;
    } 
	
	

}
