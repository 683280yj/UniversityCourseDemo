package com.chinasoft.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.filter.entity.Users;

public class UserDao extends BaseDao {

	//�����û��������ѯ�û���Ϣ
	public Users Logins(String uname,String upwd){
		String sql = "select * from users where uname = ? and upwd = ?";
		Connection con = getCon();
		PreparedStatement pre =null;
		ResultSet res = null;
		Users u =null;
		try {
			pre = con.prepareStatement(sql);
			pre.setString(1, uname);
			pre.setString(2, upwd);
			res = pre.executeQuery();
			while(res.next()){
				u = new Users();
				u.setUname(res.getString(2));
				u.setUpwd(res.getString(3));
			}
			return u;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
