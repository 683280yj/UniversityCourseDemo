package com.chinasoft.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.chinasoft.model.entity.Products;

public class ProductDao extends BaseDao {

	public List<Products> showAllPro(){
		Connection con = getCon();
		String sql = "select * from products";
		PreparedStatement pre = null;
		ResultSet res = null;
		List<Products> list = new ArrayList<Products>();
		try {
			pre = con.prepareStatement(sql);
			res = pre.executeQuery();
			while(res.next()){
				list.add(new Products(res.getInt(1), res.getInt(2), res.getString(3), res.getBigDecimal(4), res.getString(5), res.getString(6), res.getDate(7), res.getInt(8)));
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public Products queryByid(int pid){
		Connection con = getCon();
		PreparedStatement pre = null;
		ResultSet res = null;
		String sql = "select * from products where pid = ?";
		try {
			pre = con.prepareStatement(sql);
			pre.setInt(1, pid);
			res = pre.executeQuery();
			Products ps = null;
			while(res.next()){
				ps = new Products(res.getInt(1), res.getInt(2), res.getString(3), res.getBigDecimal(4), res.getString(5), res.getString(6), res.getDate(7), res.getInt(8));
			}
			return ps;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}
}
