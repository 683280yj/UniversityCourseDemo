package com.chinasoft.singleton;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;




public class LoginSessionListener implements HttpSessionAttributeListener {

   Log log= LogFactory.getLog(this.getClass());
   
   Map<String,HttpSession> map = new HashMap<String,HttpSession>();
    public LoginSessionListener() {
        // TODO Auto-generated constructor stub
    }

    public void attributeRemoved(HttpSessionBindingEvent event)  { 
    	// 删除属性前被调用   
    	String name  = event.getName();
    	if(name.equals("personInfo")){
    		Users personInfo = (Users) event.getValue();
    		map.remove(personInfo.getAccount());
    		 log.info("账号"+personInfo.getAccount()+"注销");  
    	}
    }

    public void attributeAdded(HttpSessionBindingEvent event)  { 
    	//添加属性前被调用
    	String name = event.getName();
    	if(name.equals("personInfo")){
    		Users personInfo = (Users) event.getValue();
    		if(map.get(personInfo.getAccount()) != null){
    			HttpSession session = map.get(personInfo.getAccount());
    			
    			Users oldPersonInfo = (Users) session.getAttribute("personInfo");
    			log.info("账号"+oldPersonInfo.getAccount()+"在"+oldPersonInfo.getIp()+"已经登录，该账号将被迫下线！");
    			session.removeAttribute("personInfo");
    			session.setAttribute("msg", "您的账号已经在其他机器上登录,您被迫下线！");
    			
    		}
    		map.put(personInfo.getAccount(), event.getSession());
    		log.info("账号"+personInfo.getAccount()+"在"+personInfo.getIp()+"登录");
    		
    	}
    }

    public void attributeReplaced(HttpSessionBindingEvent event)  { 
    	 // 修改属性时被调用  
    	String name = event.getName();
    	if(name.equals("personInfo")){
    		Users oldPersonInfo = (Users) event.getValue();
    		 //移除旧的登录信息  
    		map.remove(oldPersonInfo.getAccount());
    		 //新的登录信息  
    		Users personInfo = (Users) event.getSession().getAttribute("personInfo");
    		//也要验证新的账号是否在别的机器上登录  
    		if(map.get(personInfo.getAccount()) != null){
    			HttpSession session = map.get(personInfo.getAccount());
    			
    			session.removeAttribute("personInfo");
    			session.setAttribute("msg", "您的账号已经在其他机器上登录,您被迫下线！");
    			
    		}
    		map.put(personInfo.getAccount(), event.getSession());
    		log.info("账号"+personInfo.getAccount()+"在"+personInfo.getIp()+"登录");
    		
    	}
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    }
	
}
