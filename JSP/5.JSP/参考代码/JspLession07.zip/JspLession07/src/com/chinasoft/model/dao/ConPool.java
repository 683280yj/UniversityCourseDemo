package com.chinasoft.model.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.dbcp.ConnectionFactory;
import org.apache.commons.dbcp.DataSourceConnectionFactory;

public class ConPool {


	/*private static BasicDataSource dbs = null;
	private static ConnectionFactory cf = null;
	static {
		dbs = new BasicDataSource();
		dbs.setDriverClassName("com.mysql.jdbc.Driver");
		dbs.setUrl("jdbc:mysql://localhost:3306/tmall");
		dbs.setInitialSize(10);
		dbs.setMaxActive(4);
		dbs.setMaxWait(5000);
		dbs.setUsername("root");
		dbs.setPassword("root");
		cf = new DataSourceConnectionFactory(dbs);
	}
	
	public static Connection getConnection() throws SQLException{
		return cf.createConnection();
	}
	
	public static void destory() throws SQLException{
		cf = null;
		dbs.close();
		dbs = null;
	}
	public static void main(String[] args) throws SQLException {

		Connection con = ConPool.getConnection();
		System.out.println(con);
	}
*/

	public static Connection getCon() throws
	            NamingException, SQLException{

		Context initCtx = new InitialContext(); 
		Context envCtx = (Context) 			 
	    initCtx.lookup("java:comp/env"); 
		DataSource ds = (DataSource) 
		envCtx.lookup("jindText"); 
		return ds.getConnection(); 

	}

/*	public static void main(String[] args) throws NamingException, SQLException {
		Connection con  = getCon();
		System.out.println(con);
	}*/
}
