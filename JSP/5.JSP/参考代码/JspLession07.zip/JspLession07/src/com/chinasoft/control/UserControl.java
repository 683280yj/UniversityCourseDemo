package com.chinasoft.control;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.chinasoft.model.dao.UserDao;
import com.filter.entity.Users;

public class UserControl extends HttpServlet {

	private UserDao ud = new UserDao();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		String uname = request.getParameter("uname");
		String upwd = request.getParameter("upwd");
		Users us =  ud.Logins(uname, upwd);
		HttpSession session = request.getSession();
		if(us != null){
			session.setAttribute("user", us);
			request.getRequestDispatcher("ProductControl").forward(request, response);
		}else{
			session.setAttribute("msg", "�û������������������");
		}
		out.flush();
		out.close();
	}

}
