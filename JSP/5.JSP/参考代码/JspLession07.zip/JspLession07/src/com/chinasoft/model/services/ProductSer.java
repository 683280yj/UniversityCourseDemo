package com.chinasoft.model.services;
import java.sql.Connection;
import java.util.List;

import com.chinasoft.model.dao.ProductDao;
import com.chinasoft.model.entity.Products;

public class ProductSer  {

	private ProductDao pd = new ProductDao();
	public List<Products> showAllPro(){
		return pd.showAllPro();
	}
	
	public Products queryById(int pid){
		
		return pd.queryByid(pid);
	}

}
