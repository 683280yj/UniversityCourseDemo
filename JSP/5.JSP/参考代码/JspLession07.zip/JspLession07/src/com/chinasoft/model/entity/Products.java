package com.chinasoft.model.entity;

import java.math.BigDecimal;
import java.util.Date;

public class Products {

	private Integer pid;

    private Integer cateid;

    private String pname;

    private BigDecimal pprice;

    private String pimg;

    private Date paddtime;

    private Integer istj;

    private String pinfo;

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getCateid() {
        return cateid;
    }

    public void setCateid(Integer cateid) {
        this.cateid = cateid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname == null ? null : pname.trim();
    }

    public BigDecimal getPprice() {
        return pprice;
    }

    public void setPprice(BigDecimal pprice) {
        this.pprice = pprice;
    }

    public String getPimg() {
        return pimg;
    }

    public void setPimg(String pimg) {
        this.pimg = pimg == null ? null : pimg.trim();
    }

    public Date getPaddtime() {
        return paddtime;
    }

    public void setPaddtime(Date paddtime) {
        this.paddtime = paddtime;
    }

    public Integer getIstj() {
        return istj;
    }

    public void setIstj(Integer istj) {
        this.istj = istj;
    }

    public String getPinfo() {
        return pinfo;
    }

    public void setPinfo(String pinfo) {
        this.pinfo = pinfo == null ? null : pinfo.trim();
    }
    
    public Products(Integer pid, Integer cateid, String pname,
			BigDecimal pprice, String pimg,String pinfo, Date paddtime, Integer istj
			) {
		super();
		this.pid = pid;
		this.cateid = cateid;
		this.pname = pname;
		this.pprice = pprice;
		this.pimg = pimg;
		this.paddtime = paddtime;
		this.istj = istj;
		this.pinfo = pinfo;
	}
}