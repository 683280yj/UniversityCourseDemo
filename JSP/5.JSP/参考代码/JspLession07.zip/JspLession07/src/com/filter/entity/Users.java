package com.filter.entity;

public class Users {

	private String account;
	private String uname;
	private String upwd;
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpwd() {
		return upwd;
	}
	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}
	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Users(String account, String uname, String upwd) {
		super();
		this.account = account;
		this.uname = uname;
		this.upwd = upwd;
	}
	

}
