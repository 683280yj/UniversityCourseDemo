package com.filter.control;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.filter.entity.Users;

public class LoginSessionListener implements HttpSessionAttributeListener {
Map<String, String> map = new HashMap<String, String>();
Log log= LogFactory.getLog(this.getClass());  


	@Override
	public void attributeAdded(HttpSessionBindingEvent event) {
		  // ɾ������ǰ������  
        String name  = event.getName();  
        if(name.equals("personInfo")){  
            Users personInfo = (Users) event.getValue();  
            map.remove(personInfo.getAccount());  
            log.info("�˺�"+personInfo.getAccount()+"ע��");  
        }  
		
	}

	 // ɾ������ʱ������  
	@Override
	public void attributeRemoved(HttpSessionBindingEvent event) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attributeReplaced(HttpSessionBindingEvent event) {
		// TODO Auto-generated method stub
		
	}

}
